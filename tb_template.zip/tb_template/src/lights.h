#ifndef __LIGHTS_H__
#define __LIGHTS__

void putLights(u32_t ledno, bool state);
bool getLights(u32_t ledno);
void lights_init();

#endif
