#include <zephyr.h>
#include <board.h>
#include <device.h>
#include <gpio.h>
#include <misc/printk.h>
#include "math.h"
#include "config.h"
#include "tb_pubsub.h"
#include "lights.h"

#define BTN_PORT SW0_GPIO_NAME
#define BTN_COUNT 4
#define X_STEP 0.5
#define X2_MAX 120
#define X2_STEP 1.0
#define PI 3.14159265358979323846

const u32_t btn_arr[BTN_COUNT] = {
    SW0_GPIO_PIN,
    SW1_GPIO_PIN,
    SW2_GPIO_PIN,
    SW3_GPIO_PIN
};

struct device *btn_dev;
struct gpio_callback btn_callback;

int old_val[4] = {0,0,0,0};
int cur_val[4] = {0,0,0,0};
int toggle[4]  = {0,0,0,0};

float temperature = 0.0;
float x			  = 0.0;
float x2 		  = 0.0;
float A           = 10.0;
//double temperature_actuation = 0.0;

u32_t state[4];

int btn_alert_handler(struct k_alert *alert);
K_ALERT_DEFINE(btn_alert, btn_alert_handler, 10);

void btn_handler(struct device *port, struct gpio_callback *cb,
					u32_t pins)
{
    /* Context: interrupt handler */

	printk("Signalling alert!\n");
	k_alert_send(&btn_alert);
}

int btn_alert_handler(struct k_alert *alert)
{
    int set;

    int value;
    	char payload[16];

        /* Context: Zephy kernel workqueue thread */

    	printk("Button event!\n");

        /* Iterate over each button looking for a change from the previously
         * published state */
    	for (u32_t i = 0; i < BTN_COUNT; i++) {
    		gpio_pin_read(btn_dev, btn_arr[i], &value);

    		if (value==0 && state[i]==1)
    		{
    		toggle[i]=!toggle[i];
    		set=toggle[i];
    		}

    		if (value != state[i]) {
    		printk("set value, value , state[i],toggle[i] is %d===%d==%d==%d\n",set,value,state[i],toggle[i]);
                /* Formulate JSON in the format expected by thingsboard.io */
    			//snprintf(payload, sizeof(payload), "{\"btn%d\":%s}", i, toggle[i] ? "false" : "true");
    			snprintf(payload, sizeof(payload), "{\"btn%d\":%s}", i, toggle[i] ? "true" : "false");

    			tb_publish_telemetry(payload);
    			state[i] = value;
    		}
    	}

    	return 0;
}

void sensors_start()
{
	btn_dev = device_get_binding(BTN_PORT);

	for (u32_t i = 0; i < BTN_COUNT; i++) {
		gpio_pin_configure(btn_dev, btn_arr[i], GPIO_DIR_IN | GPIO_INT
			| GPIO_INT_DOUBLE_EDGE | GPIO_INT_EDGE | GPIO_PUD_PULL_UP);
	}

	gpio_init_callback(&btn_callback, btn_handler,
		BIT(btn_arr[0]) | BIT(btn_arr[1]) |
		BIT(btn_arr[2]) | BIT(btn_arr[3])
	);

	gpio_add_callback(btn_dev, &btn_callback);

	for (u32_t i = 0; i < BTN_COUNT; i++) {
		gpio_pin_enable_callback(btn_dev, btn_arr[i]);
		gpio_pin_read(btn_dev, btn_arr[i], &state[i]);
	}
}

void sensors_read(float *temperature_actuation)
{
	//float temperature_actuation;
	static char payload[128];

	if (toggle[0] == 0){
		// Temperature actuation behavior
		/*if(x2 < 61){
			temperature_actuation = (A/2)*(1/pow(60,2))*pow(x2,2);
		} else {
			temperature_actuation = -(A/2)*(1/pow(60,2))*pow((x2-120),2)+A;
		}*/

		// Sensor simulation
		temperature = 10*(1-exp(-x/10))+5+0.2*sin(2*x/PI)+(*temperature_actuation);

		if ((x2 = x2 - X2_STEP) < 0){
			x2 = 0;
		}

	} else {
		// Temperature actuation behavior
		/*if(x2 < 61){
			temperature_actuation = (A/2)*(1/pow(60,2))*pow(x2,2);
		} else {
			temperature_actuation = -(A/2)*(1/pow(60,2))*pow((x2-120),2)+A;
		}*/

		// Sensor simulation
		temperature = 10*(1-exp(-x/10))+5+0.2*sin(2*x/PI)+(*temperature_actuation);

		if ((x2 = x2 + X2_STEP) >= X2_MAX){
			x2 = X2_MAX;
		}
	}

	if ((x = x + X_STEP) >= 100){
		x = 90;
	}



	snprintf(payload, sizeof(payload), "{\"temperature\":\"%1.4f\", \"heater\":\"%d\", \"actuation\":\"%1.4f\", \"x\":\"%1.4f\", \"x2\":\"%1.4f\"}", temperature,toggle[0],temperature_actuation,x,x2);
	tb_publish_telemetry(payload);
}

void setActuation(float val)
{
	A = val;
}
