#ifndef __SENSORS_H__
#define __SENSORS_H__

void sensors_start();
void sensors_read();

#endif
